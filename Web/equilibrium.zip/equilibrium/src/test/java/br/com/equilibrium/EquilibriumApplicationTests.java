package br.com.equilibrium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EquilibriumApplicationTests {

	@Test
	void contextLoads() {
	}

}
