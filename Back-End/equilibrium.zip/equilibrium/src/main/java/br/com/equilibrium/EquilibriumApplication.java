package br.com.equilibrium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EquilibriumApplication {

	public static void main(String[] args) {
		SpringApplication.run(EquilibriumApplication.class, args);
	}

}
